# kristheamazing2-boxel-rebound-hacks
These are boxel rebound hacks that will help you when you paste the script in the console press the button to the left of the 1 on your keyboard
