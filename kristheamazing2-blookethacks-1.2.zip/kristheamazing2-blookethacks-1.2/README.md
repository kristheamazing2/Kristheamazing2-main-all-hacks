# kristheamazing2-blookethacks
This is blooket hacks for anyone 
most of these hacks are backup hacks from jHAX7 and kristheamazing2 hacks these hacks are all made from https://github.com/jHAX7/all-jHAX7-and-kristheamazing2-blooket-hacks
i worked with jHAX7 and finished the hacks with him
now I will be doing my own hacks
if these hacks get you banned it is not my fault glizzxy and others peoples hack are here
i am just updating the hacks to see if they work 
these hacks that "I" will make are different types of hacks
the recently new hack I made on jHAX7's one is OP towers, see peoples blooks, flood game and end game
make sure to go and check out jHAX7 and kristheamazing2 blooket hacks
THE ULTIMATE HACK IS STILL BEING MADE!
be ready...
