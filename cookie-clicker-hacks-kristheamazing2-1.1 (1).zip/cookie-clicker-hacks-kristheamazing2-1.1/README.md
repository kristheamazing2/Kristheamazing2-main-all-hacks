# cookie-clicker-hacks-kristheamazing2
These are cookie clicker hacks
These hacks help you to complete the game.
And check out my Wiki 
